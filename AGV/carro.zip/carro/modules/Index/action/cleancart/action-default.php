<?php

unset($_SESSION["cart"]);
include "index.php"; 



?>